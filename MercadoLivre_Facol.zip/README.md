# MercadoLivre_Facol

Projeto acadêmico desenvolvido em **Java** utilizando o padrão **MVC (Model - View - Controller)**.

## 📂 Estrutura do Projeto
- **Model** → Representa os dados (ex: Produto).
- **View** → Responsável pela interface com o usuário (ex: ProdutoView).
- **Controller** → Faz a comunicação entre Model e View (ex: ProdutoController).
- **Repository** → Gerencia a persistência dos dados em memória.

## 🚀 Como executar
1. Compile os arquivos Java:
   ```bash
   javac src/model/*.java src/view/*.java src/controller/*.java src/repository/*.java src/Main.java
   ```
2. Execute o programa:
   ```bash
   java -cp src Main
   ```

## 👨‍💻 Autor
- Nome: *Seu Nome*
- Disciplina: Programação Orientada a Objetos
- Professor: *Nome do Professor*
